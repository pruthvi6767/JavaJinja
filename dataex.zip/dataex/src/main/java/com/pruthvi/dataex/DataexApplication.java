package com.pruthvi.dataex;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DataexApplication {

	public static void main(String[] args) {
		SpringApplication.run(DataexApplication.class, args);
	}

}
